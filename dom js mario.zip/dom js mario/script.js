document.addEventListener('DOMContentLoaded', function() {
    const judul = document.getElementById('klik');
    const tombol = document.getElementById('klik2');

    tombol.addEventListener('click', function() {
        if (judul.textContent === 'Super Mario') {
            judul.textContent = 'Mario';
        } else {
            judul.textContent = 'Super Mario';
        }
    });
});